#include "Tierra.h"
#include "Bomba.h"
#include "Tablero.h"

void*** tablero;
int dimension;

void IniciarTablero(int n){
    // Su codigo
    return;
}

void PasarTurno(){
    // Su codigo
    return;
}


void ColocarBomba(Bomba* b, int fila, int columna){
    // Su codigo
    return;
}


void MostrarTablero(){
    // Su codigo
    return;
}


void MostrarBombas(){
    // Su codigo
    return;
}


void VerTesoros(){
    // Su codigo
    return;
}


void BorrarTablero(){
    // Su codigo
    return;
}