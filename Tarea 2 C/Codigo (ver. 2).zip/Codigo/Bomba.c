#include "Tierra.h"
#include "Bomba.h"
#include "Tablero.h"

void TryExplotar(int fila, int columna){
    // Su codigo
    return;
}

void BorrarBomba(int fila, int columna){
    // Su codigo
    return;
}

void ExplosionPunto(int fila, int columna){
    // Su codigo
    return;
}

void ExplosionX(int fila, int columna){
    // Su codigo
    return;
}
